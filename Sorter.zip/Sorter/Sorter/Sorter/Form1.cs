using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
using System.Data;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace Sorter
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnRun;
        private ToolTip toolTip1;
        private IContainer components;
        List<Person> people;



        public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.btnRun = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(52, 39);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(336, 88);
            this.btnRun.TabIndex = 0;
            this.btnRun.Text = "&Run";
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(10, 24);
            this.ClientSize = new System.Drawing.Size(465, 190);
            this.Controls.Add(this.btnRun);
            this.Name = "Form1";
            this.Text = "Sorter";
            this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnRun_Click(object sender, System.EventArgs e)
		{
            //initialize list to hold person object and read input file in to string array
            people = new List<Person>();
            string[] input = File.ReadAllLines("input.txt");

            //loop through array and create new person object foreach element add person to list object
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] != "")
                {
                    string[] personArray = input[i].Split(' ');
                    Person tmpPerson = new Person();
                    tmpPerson.FirstName = personArray[0];
                    try
                    { 
                        tmpPerson.LastName = personArray[1];
                    }
                    catch (Exception) { };
                    people.Add(tmpPerson);
                }
            }
            //sort list by last name then by first name
            var orderedPeople = people.OrderBy(x => x.LastName).ThenBy(x => x.FirstName);


            //save list to file in project debug fold called 'output.txt'"
            using (TextWriter tw = new StreamWriter("output.txt"))
            {
                foreach (Person p in orderedPeople.ToList())
                    tw.WriteLine(p);
            }

            //show user message that file was saved
            MessageBox.Show("File was saved as 'output.txt' in project debug fold.");
        }
	}
}
